from pathlib import Path
import json,time
from chimaera_ros.latency import stage_guest,run_case
from chimaera_ros.latency_config import DEFAULT,plan_sweep,HARDWARE
root=Path('/work');base=root/'.chimaera-m5/transport-tracing-20261024/kvm-trace-v3'
base.mkdir(exist_ok=True)
package=root/'.chimaera-m5/transport-tracing-20261024/install'
kernel=root/'.chimaera-orchestrator/assets/kernel-589cc96380009ba648cb2dcbf411e6a89193fcbd3f3d4a9dcf57d4f19bb5aeac'
config=plan_sweep(dict(DEFAULT,modes=['chimaera'],middleware_transport='fastdds',
    transport_backend='m5ops',m5_module=str(kernel/'chimaera_m5.ko'),single_boot=False,
    trace=True,payload_bytes=[518400],rate_hz=[30.],interval_us=[500],poll_us=[100],
    duration=.1,warmup=.1,drain=.05,physics_step_ns=500000,timeout=600,
    dds_shm_bytes=67108864,gem5_configs=[dict(HARDWARE,name='KVM trace validation')]))['cases'][0]['config']
started=time.monotonic()
bundle=base/'guest.tar.gz'
stage_guest(base/'stage',package,bundle)
run_case(base/'case',config,package,Path('/opt/chimaera/gem5'),
    root/'.chimaera-orchestrator/assets/ball-catching-91c08644a6f847272869.img',
    kernel/'kernel',bundle)
trace=json.loads((base/'case/transport_latency.json').read_text())
assert trace['clock_resolution_ns']==500000
streams=[s for s in trace['streams'] if s['topic']!='/latency/guest_events']
assert len(streams)==2
for stream in streams:
 assert stream['transport']['received']>0,stream
 assert stream['transport']['negative_latency']==0,stream
 assert stream['delivery']['received']>0,stream
record=dict(wall_seconds=time.monotonic()-started,purpose='KVM clock and real m5ops transport tracing integration; not a detailed-CPU performance qualification',streams=streams)
(base/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({s['topic']:{'transport':s['transport']['latency'],'delivery':s['delivery']['latency']} for s in streams},indent=2),flush=True)
