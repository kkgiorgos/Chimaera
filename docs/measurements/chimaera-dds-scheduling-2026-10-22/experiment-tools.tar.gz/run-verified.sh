#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /work/.chimaera-middleware/runtime-staging-r2/local_setup.bash
cd /work
root=/work/.chimaera-middleware/scheduling-egress-20261022
export PYTHONPATH="$root/runtime-candidate/local/lib/python3.10/dist-packages:${PYTHONPATH:-}"
python3 profiling/chimaera_rewrite/dds_large_messages.py \
  profiling/chimaera_rewrite/run_copy_cases.py "$root/verified-cases.json" "$root/runs" \
  --runtime "$root/runtime-candidate" --bundle "$root/guest-candidate.tar.gz" \
  --original-runtime "$root/runtime-baseline" --original-bundle "$root/guest-baseline.tar.gz" \
  --gem5-root /opt/chimaera/gem5 \
  --image /assets/ball-catching-5e50830490bb65fe6893.img \
  --kernel /assets/kernel-7b7d34a3b688b8ae12f5e08df8b93e9e32dc73ed66db378f6e928dacc9eab9f9/kernel \
  --append --source-snapshot "$root/candidate-source.tar.gz"
