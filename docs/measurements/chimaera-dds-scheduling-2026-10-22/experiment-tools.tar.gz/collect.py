import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

sys.path.insert(0, str(Path('profiling/chimaera_rewrite').resolve()))
from summarize_copies import summarize

root = Path('.chimaera-middleware/scheduling-egress-20261022')
output = Path('docs/measurements/chimaera-dds-scheduling-2026-10-22')
output.mkdir(parents=True, exist_ok=True)
report = summarize(root / 'runs')
assert sum(item['result'] == 'complete' for item in report['attempts']) == 8
complete = lambda row: row['published'] == row['received'] > 0 and not (
    row['missing'] or row['duplicates'] or row['reordered'])
report['performance_all_delivered'] = all(complete(row) for row in report['rows']
                                          if row['cohort'] == 'performance')
report['verified_images_all_delivered'] = all(complete(row) for row in report['rows']
    if row['cohort'] == 'verified' and row['stream'] in ('left_image', 'right_image'))
assert report['performance_all_delivered'] and report['verified_images_all_delivered']
for entry in report['aggregate']:
    entry['percentage_comparison_eligible'] = entry['cohort'] == 'performance'
    if entry['cohort'] == 'verified':
        entry['change_percent'] = None  # A single correctness run; retain all counts/means.
report['purpose'] = 'Direct DMA completion handling and immediate nonblocking router egress'
report['limitations'][-1] = (
    'End-to-end means include synchronization, scheduling, DDS and callback dispatch; '
    'the individual scheduling stages were not traced in these runs.')
report['limitations'].append(
    'The verification-enabled pair is a correctness check with one run per version, '
    'outside the three-repeat performance comparison.')
dds_hashes = {}
for item in report['attempts']:
    if item['result'] != 'complete':
        continue
    variant = 'baseline' if item['provenance']['case']['variant'] == 'original' else 'candidate'
    for path, value in item['config']['artifact_sha256'].items():
        if Path(path).name == 'libchimaera_dds_transport.so':
            dds_hashes.setdefault(variant, set()).add(value)
assert set(dds_hashes) == {'baseline', 'candidate'}
assert all(len(values) == 1 for values in dds_hashes.values())
(output / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
import csv
with (output / 'comparison.csv').open('w') as handle:
    writer = csv.DictWriter(handle, list(report['rows'][0]))
    writer.writeheader()
    writer.writerows(report['rows'])
for name in ('cases.json', 'verified-cases.json', 'candidate-source.tar.gz', 'direct-wait-only.json'):
    shutil.copy2(root / name, output / name)
with (root / 'baseline-source.tar').open('rb') as source, gzip.open(
        output / 'baseline-source.tar.gz', 'wb') as target:
    shutil.copyfileobj(source, target)
with tarfile.open(output / 'experiment-tools.tar.gz', 'w:gz') as archive:
    for name in ('run_copy_cases.py', 'summarize_copies.py', 'dds_large_messages.py'):
        archive.add(Path('profiling/chimaera_rewrite') / name, arcname='tools/' + name)
    archive.add('profiling/chimaera_latency/run_cases.py', arcname='tools/run_cases.py')
    for name in ('build.sh', 'run.sh', 'run-verified.sh', 'collect.py', 'render.py'):
        archive.add(root / name, arcname=name)
with tarfile.open(output / 'raw-evidence.tar.gz', 'w:gz') as archive:
    for path in sorted((root / 'runs').rglob('*')):
        if (path.is_file() and not path.name.startswith('readfile_') and
                not any(part in ('ign-logs', 'ros-logs') for part in path.parts)):
            archive.add(path, arcname=str(path.relative_to(root)))
    initial = Path('.chimaera-middleware/scheduling-20261022')
    for path in sorted((initial / 'runs').rglob('*')):
        if (path.is_file() and not path.name.startswith('readfile_') and
                not any(part in ('ign-logs', 'ros-logs') for part in path.parts)):
            archive.add(path, arcname='direct-wait-only/' + str(path.relative_to(initial)))
    archive.add(initial / 'candidate-source.tar.gz', arcname='direct-wait-only/candidate-source.tar.gz')
    for path in root.glob('*.log'):
        archive.add(path, arcname=path.name)

digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
provenance = dict(
    baseline_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    physical_host='ubuntu-george',
    sdk_image='sha256:c841ebb1000488c0010e21bc32a62b9d432b1a47e47f64e16501dc53bd66c8d4',
    simulation_cpu='X86KvmCPU only, two cores',
    asset_mount='read-only base image and matching kernel/module; fresh disposable guests',
    guest_image=json.loads(Path('.chimaera-orchestrator/assets/disk-provenance-5e50830490bb65fe6893.json').read_text()),
    kernel_sha256=digest(Path('.chimaera-orchestrator/assets/kernel-7b7d34a3b688b8ae12f5e08df8b93e9e32dc73ed66db378f6e928dacc9eab9f9/kernel')),
    runtime_files={variant: {str(path.relative_to(root / f'runtime-{variant}')): digest(path)
                            for path in (root / f'runtime-{variant}/lib').rglob('*') if path.is_file()}
                   for variant in ('baseline', 'candidate')},
    bundles={name: digest(root / name) for name in ('guest-baseline.tar.gz', 'guest-candidate.tar.gz')},
    sdk_tests=dict(transport=9, bridge=7, dds=2, all_passed=True),
    notes=[
        'Baseline is the committed copy-reduced transport; candidate changes direct guest readiness and admitted router egress.',
        'Endpoints, clock plugin, RMW, simulator, module and DDS profile match; the DDS router library intentionally differs.',
        'Candidate source was frozen before measurement. Documentation edits made later are not in that archive.',
        'No tracing, native performance benchmark, TimingSimpleCPU or O3 simulation was run.',
        'Per-case source_snapshot names the candidate archive for both variants; baseline source is retained separately from baseline_revision.',
        'Raw evidence excludes repeated base64 guest readfiles and redundant ROS/Gazebo log directories.',
    ])
subprocess.run([sys.executable, str(root / 'render.py'), str(output / 'comparison.json'),
                str(output / 'report.html')], check=True)
provenance['files'] = {path.name: digest(path) for path in output.iterdir()
                       if path.is_file() and path.name != 'provenance.json'}
(output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
for item in report['aggregate']:
    print(json.dumps(item))
