import json
from pathlib import Path
import sys

report = json.loads(Path(sys.argv[1]).read_text())
data = {key: report[key] for key in ('aggregate', 'rows', 'all_delivered', 'performance_all_delivered', 'verified_images_all_delivered', 'limitations')}
page = r'''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DDS scheduling comparison</title>
<style>
*{box-sizing:border-box}body{margin:0;font:14px/1.5 var(--font-sans,system-ui);color:var(--foreground,#253041)}
p{margin:12px 0}.muted,small{color:var(--muted-foreground,#687384)}
.stats{display:flex;flex-wrap:wrap;gap:24px;margin:8px 0 20px}.stats>div{flex:1;min-width:150px}
.stats strong{display:block;font-size:28px;font-weight:650;letter-spacing:-.6px}
.flow{padding:12px 0;border-top:1px solid var(--border,#d5d9e0);border-bottom:1px solid var(--border,#d5d9e0)}
label{display:inline-flex;flex-direction:column;gap:5px;margin:12px 14px 8px 0}select{padding:7px;font:inherit;color:inherit;background:var(--background,#fff);border:1px solid var(--border,#ccd3dc);border-radius:6px}
.legend{display:flex;gap:20px;margin:12px 0}.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}
.baseline{background:var(--chart-1,#8260ca)}.candidate{background:var(--chart-2,#269aa5)}
.run{display:grid;grid-template-columns:105px 1fr 68px;gap:10px;align-items:center;margin:9px 0}.track{height:16px;background:var(--muted,#eef0f3);border-radius:3px;overflow:hidden}.bar{height:16px;border-radius:3px}.value{text-align:right;font-variant-numeric:tabular-nums}
table{border-collapse:collapse;width:100%;margin:16px 0}th,td{padding:8px 4px;border-bottom:1px solid var(--border,#d6dce4);text-align:right;font-variant-numeric:tabular-nums}th:first-child,td:first-child{text-align:left}
.note{border-left:3px solid var(--border,#cbd2dc);padding-left:12px;margin:16px 0}details{margin:16px 0}summary{cursor:pointer}
@media(max-width:460px){.run{grid-template-columns:96px 1fr 60px;gap:5px}.stats{gap:10px}.stats strong{font-size:24px}table{font-size:12px}}
</style>
<div class="stats"><div><strong id="change"></strong>stereo-pair mean · verifier off · 3 repeats</div><div><strong id="delivered"></strong>measured images delivered</div></div>
<p class="note" id="tail"></p>
<p class="note" id="delivery"></p>
<p class="flow">DMA interrupt → coordinator poll/read → immediate router send → DDS reader / application executor</p>
<p>The DDS guest coordinator consumes DMA completions directly. Router notifications and shutdown use a persistent eventfd. Admitted packets attempt nonblocking socket delivery immediately; slow recipients retain their FIFO queue and DMA loan. Legacy bridge sessions retain the completion worker and ROS executor.</p>
<label>Stream<select id="stream"><option value="stereo_pairs">Complete stereo pair</option><option value="left_image">Left image</option><option value="right_image">Right image</option><option value="joint_states">Joint feedback</option><option value="effort_command">Effort command</option><option value="clock">Clock</option></select></label>
<label>Cohort<select id="cohort"><option value="performance">Verifier off · 3 repeats</option><option value="verified">Verifier on · 1 run</option></select></label>
<label>Per-run metric<select id="metric"><option value="mean_ms">Mean delay</option><option value="p95_ms">Observed p95</option><option value="max_ms">Observed maximum</option></select></label>
<div class="legend"><span><i class="dot baseline"></i>Completion worker + executor</span><span><i class="dot candidate"></i>Direct readiness</span></div>
<div id="chart" role="img" aria-label="Per-run publication-to-callback latency, in simulation milliseconds"></div>
<table><thead><tr><th>Implementation</th><th>Received / published</th><th>Mean</th><th>Maximum</th></tr></thead><tbody id="table"></tbody></table>
<p class="muted" id="counts"></p>
<p class="note">Two-core KVM, 2 ms coupling / 1 ms physics, 480 × 360 RGB stereo at 30 Hz, 250 Hz joints/efforts and 1 kHz clock. One-second source window, 0.25 s warmup and 0.75 s drain. Endpoints, DDS profile, RMW, clock plugin, kernel/module and simulator match.</p>
<p class="muted">KVM does not model detailed CPU or memory costs. These short independent runs do not establish stable tails. Delays include the entire transport and callback path; they do not isolate time in the scheduler. The verification cohort checks every image byte after its callback timestamp and can delay later callbacks.</p>
<script>
const data=__DATA__;
const number=x=>x==null?'—':x.toFixed(2)+' ms';
const pair=data.aggregate.find(x=>x.cohort==='performance'&&x.stream==='stereo_pairs');
document.querySelector('#change').textContent=(pair.change_percent<0?'−':'+')+Math.abs(pair.change_percent).toFixed(1)+'%';
document.querySelector('#tail').textContent='Observed stereo p95 is higher in all three repeats; the maximum rises from '+number(pair.baseline.max_ms)+' to '+number(pair.candidate.max_ms)+'. Mean latency improves with a tail tradeoff.';
const verifiedPair=data.aggregate.find(x=>x.cohort==='verified'&&x.stream==='stereo_pairs');
const losses=data.rows.filter(x=>x.cohort==='verified'&&x.missing);
document.querySelector('#delivery').textContent='Performance: every measured message delivered. Byte-verification cohort: '+(losses.length?losses.map(x=>x.case+' '+x.stream+' '+x.received+'/'+x.published).join('; ')+'. These shortfalls remain in the evidence.':'every measured message delivered.')+' Verifier-on stereo means: '+number(verifiedPair.baseline.mean_ms)+' → '+number(verifiedPair.candidate.mean_ms)+', one run per version.';
const images=data.rows.filter(x=>['left_image','right_image'].includes(x.stream));
document.querySelector('#delivered').textContent=images.reduce((n,x)=>n+x.received,0)+' / '+images.reduce((n,x)=>n+x.published,0);
function draw(){
 const stream=document.querySelector('#stream').value,cohort=document.querySelector('#cohort').value,metric=document.querySelector('#metric').value;
 const rows=data.rows.filter(x=>x.stream===stream&&x.cohort===cohort),scale=Math.max(...rows.map(x=>x[metric]))||1;
 document.querySelector('#chart').innerHTML=rows.map(x=>`<div class="run"><small>${x.case}</small><div class="track"><div class="bar ${x.variant}" style="width:${100*x[metric]/scale}%"></div></div><span class="value">${number(x[metric])}</span></div>`).join('');
 const aggregate=data.aggregate.find(x=>x.stream===stream&&x.cohort===cohort);
 document.querySelector('#table').innerHTML=['baseline','candidate'].map(v=>{const x=aggregate[v];return `<tr><td>${v==='baseline'?'Worker + executor':'Direct readiness'}</td><td>${x.received} / ${x.published}</td><td>${number(x.mean_ms)}</td><td>${number(x.max_ms)}</td></tr>`}).join('');
 document.querySelector('#counts').textContent=`Missing: ${rows.reduce((n,x)=>n+x.missing,0)} · duplicates: ${rows.reduce((n,x)=>n+x.duplicates,0)} · reordered: ${rows.reduce((n,x)=>n+x.reordered,0)}. Means are weighted by receipts. The bars retain individual runs; p95 values are not averaged.`;
}
document.querySelectorAll('select').forEach(x=>x.addEventListener('change',draw));draw();
for(const cohort of ['performance','verified'])for(const stream of ['stereo_pairs','left_image','right_image','joint_states','effort_command','clock']){document.querySelector('#cohort').value=cohort;document.querySelector('#stream').value=stream;draw();}
document.querySelector('#cohort').value='performance';document.querySelector('#stream').value='stereo_pairs';draw();
console.log('All views rendered; performance delivery:',data.performance_all_delivered,'verified images:',data.verified_images_all_delivered,'all cohorts/streams:',data.all_delivered);
</script></html>'''
Path(sys.argv[2]).write_text(page.replace('__DATA__', json.dumps(data).replace('</', '<\\/')))
