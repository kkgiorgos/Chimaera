import csv, hashlib, json, tarfile, sys, shutil
from pathlib import Path
sys.path.insert(0,str(Path('profiling/chimaera_rewrite').resolve()))
from analyze_pipeline import analyze
from render_pipeline import render
root=Path('.chimaera-middleware/image-profile-20261021')
out=Path('docs/measurements/chimaera-dds-image-pipeline-2026-10-21')
out.mkdir(parents=True,exist_ok=True)
parents=['baseline','kvm-baseline','traces','followup','overlay-off','quantum','gated-off']
cases=[];matrix=[];history=[];files=[]
for parent in parents:
 for case in sorted((root/parent).glob('*')):
  if not case.is_dir(): continue
  prov=case/'profile-provenance.json'
  if prov.exists():
   p=json.loads(prov.read_text());history.append(dict(group=parent,name=case.name,result=p['result'],error=p.get('error')))
  summary=case/'summary.json'
  if not summary.exists():continue
  run=json.loads((case/'run.json').read_text());s=json.loads(summary.read_text())
  left=s['streams']['left_image'];right=s['streams']['right_image']
  row=dict(name=case.name,group=parent,cpu=run['cpu'],cores=run.get('num_cores',2),interval_us=run['interval_us'],verify_payload=run['verify_payload'],left_mean_ms=left['latency']['mean_ms'],right_mean_ms=right['latency']['mean_ms'],right_max_ms=right['latency']['max_ms'],images_received=left['received']+right['received'],wall_seconds=run['wall_seconds'],traced=bool(list(case.glob('**/pipeline-*.csv'))))
  cfg=case/'gem5/config.json'
  if cfg.exists():
   c=json.loads(cfg.read_text());row.update(sim_quantum_ns=c['sim_quantum']/1000,memory_mode=c['board']['mem_mode'])
  row.update(image_missing_at_drain=left['missing_at_drain']+right['missing_at_drain'], clock_missing_at_drain=s['streams']['clock']['missing_at_drain'], clock_published=s['streams']['clock']['published'], all_streams_complete=all(m['published']==m['received'] and not any(m[k] for k in ('missing_at_drain','duplicates','reordered')) for m in s['streams'].values()))
  matrix.append(row)
  if row['traced']:
   a=analyze(case);a['group']=parent;a['cores']=row['cores'];a['sim_quantum_ns']=row.get('sim_quantum_ns');cases.append(a)
  for name in ['run.json','summary.json','events.csv','commands.json','profile-provenance.json','dds-overlay.json','guest-session.json','dds.xml','driver.log']:
   p=case/name
   if p.exists():files.append(p)
  files.extend(case.glob('**/pipeline-*.csv'))
  files.extend(case.glob('gem5/dma-debug.log'))
  files.extend(case.glob('gem5/latency_clock_origin.json'))
 # Retain failed attempt metadata without exporting failed data as a comparison.
 for p in (root/parent).glob('*/profile-provenance.json'):
  if p not in files:files.append(p)
for name in ['baseline-cases.json','kvm-cases.json','trace-cases.json','trace-followup-cases.json','overlay-off-cases.json','quantum-cases.json','build.log','build-r2.log','stage.log','baseline.log','kvm-baseline.log','traces.log','followup.log','overlay-off.log','quantum.log','export.py','sdk-image-id.txt','physical-host.txt','gated-off-cases.json','gated-build.log','gated-stage.log','gated-off.log']:
 p=root/name
 if p.exists():files.append(p)
files.append(root/'runtime-q100us/share/chimaera_ros_bridge/config/gem5_latency.py')
files.extend((root/'asset-metadata').glob('*.json'))
files=list(dict.fromkeys(files))
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
shutil.copy2(root/'profile-source.tar.gz',out/'profile-source.tar.gz')
shutil.copy2(root/'profile-source-gated.tar.gz',out/'profile-source-gated.tar.gz')
notes=[
 'All newly executed guest simulations use X86KvmCPU; native modes execute without a guest.',
 'The frozen no-verify KVM baseline overlapped the start of the first traced pilot; later traced cases and controls ran sequentially. Treat this as a scheduling confound, not a controlled overhead estimate.',
 'The first followup with guest_diagnostics stalled before complete guest event export. It was stopped by SIGTERM to its driver and is retained as failed.',
 'The first two KVM cases in baseline failed preflight because the container lacked the KVM device group; no VM measurement was produced.',
 'The quantum experiment changes only the installed gem5 Python config to a 100 us KVM event-queue quantum; guest binary hashes remain unchanged.',
 'The original overlay-off controls leave the export deadline clock read enabled. The gated-off controls disable it with the recorder; the separate gated source archive records this correction.',
 'Clock and CPU-time fields from guest Linux are quantized. Cross-core KVM stages can violate causal timestamp order; rejected joins remain in analysis.json.',
]
provenance=dict(base_revision=__import__('subprocess').check_output(['git','rev-parse','HEAD'],text=True).strip(), sdk_image=(root/'sdk-image-id.txt').read_text().strip(), physical_host=(root/'physical-host.txt').read_text().strip(), gated_runtime_source_sha256=hashlib.sha256((root/'profile-source-gated.tar.gz').read_bytes()).hexdigest(), quantum_config_sha256=hashlib.sha256((root/'runtime-q100us/share/chimaera_ros_bridge/config/gem5_latency.py').read_bytes()).hexdigest(), runtime_source_sha256=hashlib.sha256((root/'profile-source.tar.gz').read_bytes()).hexdigest(), profiler_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('profiling/chimaera_rewrite').glob('*pipeline*') if p.is_file()}, assumptions=notes)
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
data=dict(cases=cases,matrix=matrix,notes=notes)
(out/'analysis.json').write_text(json.dumps(data,indent=2)+'\n')
(out/'attempt-history.json').write_text(json.dumps(history,indent=2)+'\n')
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (out/'comparison.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in matrix for k in row)));writer.writeheader();writer.writerows(matrix)
(out/'report.html').write_text(render(data))
print('completed',len(matrix),'profiled',len(cases),'attempts',len(history))
for row in matrix:print(row['name'],round(row['left_mean_ms'],3),round(row['right_mean_ms'],3),round(row['right_max_ms'],3))
print('rejected',[(c['case'],len(c['errors']),len(c['dma_join_errors'])) for c in cases])
