#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /opt/chimaera/ros/share/chimaera_ros_bridge/local_setup.bash
source /opt/chimaera/ball/franka_description/share/franka_description/local_setup.bash
source /opt/chimaera/ball/ball_catching_robot/share/ball_catching_robot/local_setup.bash
source /opt/chimaera/ball/ball_catching_sim/share/ball_catching_sim/local_setup.bash
cd /app
common=(python3 /app/ros/ball_catching_ws/scripts/run_memory_suite.py --config /assets/inputs/experiment.json --gem5-root /opt/chimaera/gem5 --image /assets/guest.img --kernel /assets/kernel --output /output --source-revision 0370f1b03919c2bc207f81ad6e37b1384fc1e320)
"${common[@]}" --prepare-only --bundle-from /assets/inputs/prepared/guest.tar.gz
"${common[@]}" --checkpoint-create --resume
