#!/bin/bash
set -eo pipefail
source /opt/chimaera/ros/setup.bash
source /opt/chimaera/ball/franka_description/share/franka_description/local_setup.bash
source /opt/chimaera/ball/ball_catching_robot/share/ball_catching_robot/local_setup.bash
source /opt/chimaera/ball/ball_catching_sim/share/ball_catching_sim/local_setup.bash
export LD_LIBRARY_PATH=/work/.chimaera-m5/transport-tracing-20261024/build/chimaera_dds_transport:$LD_LIBRARY_PATH
cd /app
python3 /app/ros/ball_catching_ws/scripts/run_memory_suite.py --config /work/.chimaera-m5/readiness-regression-20261024/kvm-config.json --gem5-root /opt/chimaera/gem5 --image /assets/guest.img --kernel /assets/kernel --output /output --source-revision 625b47b12129baa81ac0176e00be78a693b28698 --resume --checkpoint-from /output/checkpoints --calibration-from /assets/inputs/prepared/calibration --case case-000
