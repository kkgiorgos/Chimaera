"""Actual robot capture/restore validation using the managed overnight assets."""
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

root = Path('/work')
output = root / '.chimaera-m5/perception-recovery-20261024/validation-v2'
output.mkdir(exist_ok=True)
sys.path.insert(0, str(root / 'ros/ball_catching_ws/scripts'))
from run_memory_suite import digest, gem5_trial, load_config, plan, prepare_bundle, write_json
from readiness_checkpoint import freeze, key, provenance, validate

mode = sys.argv[1]
original = root / '.chimaera-orchestrator/experiments/52c15e35701e4bfbb5de0b3045db219e'
raw = json.loads((original / 'request.json').read_text())['config']
raw['patterns'], raw['pressure'] = ['random'], [0]
raw['ramulator_config'] = str(root / raw['ramulator_config'])
kernel = root / '.chimaera-orchestrator/assets/kernel-589cc96380009ba648cb2dcbf411e6a89193fcbd3f3d4a9dcf57d4f19bb5aeac'
raw['fixed'].update(m5_module=str(kernel / 'chimaera_m5.ko'), startup_timeout_s=900,
                    wall_timeout_s=3600, image_diagnostics=False)
if mode == 'kvm':
    raw['hardware']['cpu_type'] = 'kvm'
    raw['fixed']['readiness_checkpoint'] = False
if mode.startswith('smoke'):
    raw['fixed']['duration'] = .002
config = output / (mode + '-config.json')
write_json(config, raw)
data = load_config(config)
points = plan(data)
point = points[1] if mode == 'loft5' else points[0]
bundle = output / 'guest.tar.gz'
args = SimpleNamespace(image=root / '.chimaera-orchestrator/assets/ball-catching-91c08644a6f847272869.img',
                       kernel=kernel / 'kernel', gem5_root=Path('/opt/chimaera/gem5'))
if mode == 'stage':
    assert not bundle.exists(), 'Do not replace a frozen validation bundle'
    bundle = prepare_bundle(output, data, points)
    write_json(output / 'frozen-artifacts.json', dict(config=raw, artifacts={
        str(p): digest(p) for p in (bundle, args.image, args.kernel,
                                   args.gem5_root / 'build/X86/gem5.opt')}))
    raise SystemExit(0)
frozen = json.loads((output / 'frozen-artifacts.json').read_text())
assert all(digest(Path(p)) == expected for p, expected in frozen['artifacts'].items())
checkpoints = output / 'checkpoints'
directory = output / mode
started = time.monotonic()
identity = provenance(args.gem5_root / 'build/X86/gem5.opt', args.kernel, args.image, bundle)
if mode == 'capture':
    directory = checkpoints / key(data, point)
    gem5_trial(directory, output, data, point, args, {}, bundle, checkpoint_prepare=directory)
    freeze(checkpoints, identity, [directory.name])
else:
    saved = validate(checkpoints, data, point, identity) if mode != 'kvm' else None
    gem5_trial(directory, output, data, point, args, {}, bundle, checkpoint_restore=saved)
    if mode.startswith('smoke'):
        assert not Path('/dev/kvm').exists(), 'Restore must run without KVM'
        for marker in ('checkpoint-record-readers-ready', 'checkpoint-reconnected', 'checkpoint-release'):
            assert (directory / marker).is_file(), marker
        counts = json.loads((saved / 'gem5/checkpoint-record-counts.json').read_text())
        received = {}
        for line in (directory / 'guest_records.jsonl').read_text().splitlines():
            envelope = json.loads(line)
            stream = envelope['stream']
            assert envelope['sequence'] == received.get(stream, 0), 'Record sequence gap'
            received[stream] = envelope['sequence'] + 1
        for stream in ('perception', 'control_timing'):
            assert received[stream] > counts[stream], 'No new ' + stream
        assert (directory / 'gem5/measurement_start.json').is_file()
        assert json.loads((directory / 'launch_validation.json').read_text())['valid']
score = json.loads((directory / 'result.json').read_text()) if (directory / 'result.json').exists() else None
record = dict(mode=mode, directory=str(directory), wall_seconds=time.monotonic() - started, score=score)
write_json(output / (mode + '-validation.json'), record)
print(json.dumps(record), flush=True)
