# Fast DDS middleware validation, ubuntu-george, 2026-10-21

See the [implementation and measurement report](../../chimaera-dds-middleware.md).

`ball-result.json`, `ball-benchmark.json`, `ball-execution.json`,
`ball-launch-validation.json` and `ball-provenance.json` retain the clean KVM
baseline result, configuration, scoring and artifact identities. `ball-ages.json`
contains ages of received records during the throw, and `ball-wall-phases.json`
aggregates the step timing records. `application-source-check.json` records that
the normal robot application package is unchanged. The base revision plus the
retained source patch identify builds made before their changes were committed.

`runtime-provenance.json` fingerprints the immutable `runtime-queue-r1` prefix
and matching latency guest bundle. `runtime-versions.txt` records SDK versions.
`transport-tests.log`, `queue-tests.log` and `bridge-tests.log` retain CTest
results. `report-tests.log` covers matched control and report analysis checks.

Diagnostic evidence is separate: `ball-clock-diagnostic-*.json`, `clock-probe.json`,
`dma-startup-progress.txt`, and `queue-overflow-attempt.json`. The native baseline
is also retained. Diagnostic and failed attempts are not performance samples.

Raw runs, including every interrupted attempt, remain locally under the ignored
`.chimaera-middleware/` directory. The clean application run is
`ball-acceptance-r5`; the matched benchmark is `latency-acceptance-r2`.
The earlier benchmark directory retains the timeout-parameter startup failure.
Latency results are still being collected.
