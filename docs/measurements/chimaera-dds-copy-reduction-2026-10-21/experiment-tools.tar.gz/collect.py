import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('.chimaera-middleware/copy-reduction-20261021')
output = Path('docs/measurements/chimaera-dds-copy-reduction-2026-10-21')
output.mkdir(parents=True, exist_ok=True)
subprocess.run(['python3', 'profiling/chimaera_rewrite/summarize_copies.py',
                str(root/'runs'), str(output)], check=True, stdout=subprocess.DEVNULL)
subprocess.run(['python3', 'profiling/chimaera_rewrite/render_copies.py',
                str(output/'comparison.json'), str(output/'report.html')], check=True)
for name in ('cases.json', 'verified-repeat-cases.json', 'bounded-cases.json',
             'bounded-retry-cases.json', 'candidate-process-libraries.json'):
    shutil.copy2(root/name, output/name)
shutil.copy2(root/'candidate-source.tar.gz', output/'candidate-source.tar.gz')
with (root/'baseline-source.tar').open('rb') as source, gzip.open(output/'baseline-source.tar.gz', 'wb') as target:
    shutil.copyfileobj(source, target)
with tarfile.open(output/'experiment-tools.tar.gz', 'w:gz') as archive:
    for name in ('run_copy_cases.py', 'summarize_copies.py', 'render_copies.py', 'dds_large_messages.py'):
        archive.add(Path('profiling/chimaera_rewrite')/name, arcname='tools/'+name)
    archive.add('profiling/chimaera_latency/run_cases.py', arcname='tools/run_cases.py')
    for name in ('build.sh', 'run.sh', 'run-bounded.sh', 'run-verified-repeat.sh', 'collect.py'):
        archive.add(root/name, arcname=name)
with tarfile.open(output/'raw-evidence.tar.gz', 'w:gz') as archive:
    for folder in ('runs', 'bounded-runs'):
        for path in sorted((root/folder).rglob('*')):
            if (path.is_file() and not path.name.startswith('readfile_') and
                    not any(part in ('ign-logs', 'ros-logs') for part in path.parts)):
                archive.add(path, arcname=str(path.relative_to(root)))
    for path in root.glob('*.log'):
        archive.add(path, arcname=path.name)
bounded_dir = root/'bounded-runs/candidate-bounded-verified-r2'
bounded = json.loads((bounded_dir/'summary.json').read_text())
origin = json.loads((bounded_dir/'clock-origin.json').read_text())
assert origin['active_cpus'] == ['X86KvmCPU', 'X86KvmCPU']
assert bounded['config']['dma_module_options'] == 'buffer_mb=8 receive_slots=4 transmit_slots=2'
command = json.loads((bounded_dir/'guest-session.json').read_text())['guest']['processes'][0]['command']
assert command[:2] == ['/bin/bash','-ec'] and 'dds_router_test; echo CHIMAERA_COPY_ROUTER_TESTS_PASSED; exec "$@"' in command[2]
assert all(value['received'] == value['published'] > 0 and not any(value[key] for key in ('missing_at_drain', 'duplicates', 'reordered')) for value in bounded['streams'].values())
(output/'bounded-summary.json').write_text(json.dumps(dict(summary=bounded, origin=origin,
    router_tests_passed=True, attempts=json.loads((root/'bounded-runs/progress.json').read_text())), indent=2)+'\n')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
provenance = dict(
    base_revision='0e7640bdcf50022c66031f8697a6bda2a88b59d0',
    measurement_checkout_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    sdk_image='sha256:c841ebb1000488c0010e21bc32a62b9d432b1a47e47f64e16501dc53bd66c8d4',
    physical_host='ubuntu-george',
    simulation_cpu='X86KvmCPU only',
    native_tests_run=False,
    guest_image=json.loads(Path('.chimaera-orchestrator/assets/disk-provenance-5e50830490bb65fe6893.json').read_text()),
    kernel_sha256=digest(Path('.chimaera-orchestrator/assets/kernel-7b7d34a3b688b8ae12f5e08df8b93e9e32dc73ed66db378f6e928dacc9eab9f9/kernel')),
    files={path.name:digest(path) for path in output.iterdir() if path.is_file() and path.name!='provenance.json'},
    runtime_files={variant:{str(path.relative_to(root/f'runtime-{variant}')):digest(path)
                   for path in (root/f'runtime-{variant}/lib').rglob('*') if path.is_file()}
                   for variant in ('baseline','candidate')},
    guest_bundle_sha256={name:digest(root/name) for name in ('guest-baseline.tar.gz','guest-candidate.tar.gz','guest-bounded.tar.gz')},
    notes=['Generic run_cases source_snapshot identifies the candidate source archive for the matrix. Baseline source is retained separately from git archive of base_revision.',
           'The candidate runtime source archive was frozen before measurement. Final orchestration/export helpers are in experiment-tools.tar.gz.',
           'Raw evidence omits generated readfiles containing repeated base64 guest bundles; commands, bundle hashes, source snapshots and runtime file hashes are retained.',
           'The first candidate run completes the guarded router regression before endpoint startup; serial output may remain buffered at managed shutdown.',
           'The first bounded-pool attempt with an additional preflight log exporter failed during guest startup before measurement. Its raw failure remains retained. The retry omits that extra exporter and uses the original fail-fast regression guard.',
           'Kernel and guest image were mounted read-only; no image deployment was performed.'])
(output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(output)
