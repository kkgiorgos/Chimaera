#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
source /work/.chimaera-middleware/runtime-staging-r2/local_setup.bash
cd /work
root=/work/.chimaera-middleware/copy-reduction-20261021
variant=$1
if [[ $variant == baseline ]]; then
  src=$root/baseline-source/ros/chimaera_ros_ws/src
  transport=$root/baseline-source/gem5-transport
  testing=OFF
else
  src=/work/ros/chimaera_ros_ws/src
  transport=/work/gem5-transport
  testing=ON
fi
colcon --log-base "$root/log-$variant" build --merge-install \
  --base-paths "$src/chimaera_dds_transport" "$src/chimaera_ros_bridge" \
  --packages-select chimaera_dds_transport chimaera_ros_bridge \
  --build-base "$root/build-$variant" --install-base "$root/runtime-$variant" \
  --cmake-args -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=$testing \
  -DBUILD_GAZEBO_BRIDGE=ON -DBUILD_LATENCY_BENCHMARK=ON \
  -DGEM5_TRANSPORT_ROOT="$transport" -DGEM5_ROOT=/src/gem5 \
  -DGEM5_M5_LIBRARY=/opt/chimaera/gem5/util/m5/build/x86/out/libm5.a
cp /work/.chimaera-middleware/runtime-staging-r2/lib/librmw_fastrtps{,_shared}_cpp.so \
  "$root/runtime-$variant/lib/"
if [[ $variant == candidate ]]; then
  cp "$root/build-$variant/chimaera_dds_transport/dds_router_test" \
    "$root/runtime-$variant/lib/chimaera_ros_bridge/"
fi
source "$root/runtime-$variant/local_setup.bash"
export PYTHONPATH="$root/runtime-$variant/local/lib/python3.10/dist-packages:${PYTHONPATH:-}"
python3 "$root/runtime-$variant/lib/chimaera_ros_bridge/chimaera_latency" stage \
  --output "$root/guest-$variant" --bundle "$root/guest-$variant.tar.gz"
